package com.mikel.intentsimplicitos;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Button loginButton = null;
    private Button signUpButton = null;
    private ArrayList<User> userArrayList = new ArrayList<>();
    public static final int DASHBOARD_ACTIVITY = 1;
    public static final int SIGNUP_ACTIVITY = 2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.loginButton = (Button) findViewById(R.id.btnLogin);
        this.signUpButton = (Button) findViewById(R.id.btnSignUp);

        // Add users (admin and user) to the arrayList so we can login with them.
        this.userArrayList.add(new User("admin", "admin"));
        this.userArrayList.add(new User("user", "user"));

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signUp();
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        User user = (User) data.getExtras().getSerializable("user");
        this.userArrayList.add(user);
    }

    public void login() {
        EditText txtLogin = (EditText) findViewById(R.id.txtLogin);
        EditText txtPassword = (EditText) findViewById(R.id.txtPassword);

        String loginText = txtLogin.getText().toString().trim();
        String passwordText = txtPassword.getText().toString().trim();
        Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
        // Variables for the while loop
        int i = 0;
        boolean found = false;

        while (i < this.userArrayList.size() && !found) {
            if (this.userArrayList.get(i).getUsername().equalsIgnoreCase(loginText)
                    && this.userArrayList.get(i).getPassword().equalsIgnoreCase(passwordText)) {
                found = true;
                intent.putExtra("username", this.userArrayList.get(i).getUsername());
            }
            i++;
        }

        if (found) {
            startActivityForResult(intent, DASHBOARD_ACTIVITY);
        } else {
            showToast(getString(R.string.wrong_credentials));
        }
    }

    public void signUp() {
        Intent intent = new Intent(MainActivity.this, SignUpActivity.class);
        startActivityForResult(intent, SIGNUP_ACTIVITY);
    }

    public void showToast(CharSequence message) {
     Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }


}